--[[
  Quick Stack Area v1.1.0  (Enshrouded Mod Loader / EML, Lua data patch)

  Sets the area of the Quick Stack Station and the Large Quick Stack Station.
  Internally the game calls quick stacking "area deposit". The stations are the ECS templates
  Prop_Storage_Loot_Drop_Station_16x16 and Prop_Storage_Loot_Drop_Station_24x24. Each holds:

    keen::ecs::TriggerShape (shape Box): rangeX / rangeY / rangeZ are HALF sizes
      (16x16 station: 8 / 2 / 8, 24x24 station: 12 / 4 / 12); offset.localOffset.y lifts the box
      (1.5 / 3.5, so the box bottom sits 0.5 below the station).
      This box decides which chests receive items.
      The config "Height" is how far the area reaches up; "DepthBelow" (1.1.0) lowers the box bottom
      further, e.g. into a basement: box from -(0.5 + depth) to height - 0.5, so
      rangeY = (height + depth) / 2 and localOffset.y = (height - depth) / 2 - 0.5.
    keen::ecs::VfxParametersTemplateComponent: parameters.data holds the outline's values as raw
      float bits: [1] full X, [2] full height, [3] full Z, [9] height offset.

    The placement outline and the flashes on E are other outline effects with their own parameter
    blocks (the effect's defaults, keen::VfxResource.defaultParameterData, and the stations'
    notifiers); they are found by their colour and the stations' original sizes (see main()).

  Config "X" and "Y" are the two floor directions (game rangeX and rangeZ; the game's Y is up).
  The game tests chests against the world-aligned bounding box of the station's rotated box. The
  outlines are drawn world-aligned; for a non-square area the companion plugin
  Scripts\QuickStackArea.asi resizes them as the station turns (visual only, client side).

  The whole patch runs inside pcall: a Lua error here must never stop the EML mod loader
  (an uncaught error stops ALL mods and the game will not start).

  Credits: settings reader and safe field helpers follow Auto Loot Plus by Dellemann
  (MIT License, see "licences/MIT LICENSE.txt"). Requires the Enshrouded Mod Loader by brabb3l.
]]

local TAG = "[Quick Stack Area]"
local VERSION = "1.1.0"

local MIN_SIZE, MAX_SIZE = 1, 512
-- settings that may be 0 (how far the area reaches below the station)
local MIN_ZERO = { quickStackDepthBelow = true, largeQuickStackDepthBelow = true }

---------------------------------------------------------------------------
-- Settings
---------------------------------------------------------------------------

local defaults = {
    enabled = true,
    quickStackSizeX = 16,
    quickStackSizeY = 16,
    quickStackHeight = 4,
    largeQuickStackSizeX = 24,
    largeQuickStackSizeY = 24,
    largeQuickStackHeight = 8,
    quickStackDepthBelow = 0,
    largeQuickStackDepthBelow = 0,
    logDetails = false,
}

local function strip(text)
    return (tostring(text):gsub("^%s+", ""):gsub("%s+$", ""))
end

local function parseBool(value)
    local v = value:lower()
    if v == "true" or v == "1" or v == "yes" or v == "on" then return true end
    if v == "false" or v == "0" or v == "no" or v == "off" then return false end
    return nil
end

local function loadSettings()
    local result = {}
    for key, value in pairs(defaults) do result[key] = value end

    local okExists, exists = pcall(io.exists, "config.txt")
    if not okExists or not exists then
        print(TAG .. " config.txt not found, using defaults")
        return result
    end
    local okRead, text = pcall(io.read_to_string, "config.txt")
    if not okRead or type(text) ~= "string" then
        print(TAG .. " could not read config.txt, using defaults")
        return result
    end

    for rawLine in text:gmatch("[^\r\n]+") do
        local line = strip((rawLine:gsub("[#;].*$", "")))
        local key, value = line:match("^([%w_]+)%s*=%s*(.-)$")
        if key and defaults[key] ~= nil then
            if type(defaults[key]) == "boolean" then
                local b = parseBool(value)
                if b ~= nil then result[key] = b
                else print(TAG .. " bad value for " .. key .. ", using " .. tostring(result[key])) end
            else
                local n = tonumber(value)
                if n then
                    local low = MIN_ZERO[key] and 0 or MIN_SIZE
                    if n < low or n > MAX_SIZE then
                        local clamped = math.max(low, math.min(MAX_SIZE, n))
                        print(string.format("%s %s=%s out of range, using %s", TAG, key, tostring(n), tostring(clamped)))
                        n = clamped
                    end
                    result[key] = n
                else
                    print(TAG .. " bad value for " .. key .. ", using " .. tostring(result[key]))
                end
            end
        elseif key then
            print(TAG .. " unknown setting ignored: " .. key)
        end
    end
    return result
end

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------

local function field(object, key)
    if object == nil then return nil end
    local ok, value = pcall(function() return object[key] end)
    if ok then return value end
end

local function setField(object, key, value)
    if object == nil then return false end
    return (pcall(function() object[key] = value end))
end

local function near(a, b)
    return type(a) == "number" and math.abs(a - b) < 0.001
end

local function size(v)
    if type(v) == "number" then return tostring(v * 2) end
    return "?"
end

local function findComponent(components, wanted)
    for _, component in ipairs(components or {}) do
        if field(component, "type") == wanted then return field(component, "value") end
    end
end

-- float <-> raw 32-bit pattern (the VFX parameters are stored as uint32)
local function floatBits(f)
    local ok, bits = pcall(function() return (string.unpack("<I4", string.pack("<f", f))) end)
    if ok then return bits end
    ok, bits = pcall(function()
        local b = buffer.create(4)
        b:write_f32(f)
        b:head(0)
        return b:read_u32()
    end)
    if ok then return bits end
end

local function bitsFloat(bits)
    local ok, f = pcall(function() return (string.unpack("<f", string.pack("<I4", bits))) end)
    if ok then return f end
end

---------------------------------------------------------------------------
-- Patch
---------------------------------------------------------------------------

local STATIONS = {
    { template = "Prop_Storage_Loot_Drop_Station_16x16", label = "Quick Stack Station",
      x = "quickStackSizeX", y = "quickStackSizeY", h = "quickStackHeight", d = "quickStackDepthBelow" },
    { template = "Prop_Storage_Loot_Drop_Station_24x24", label = "Large Quick Stack Station",
      x = "largeQuickStackSizeX", y = "largeQuickStackSizeY", h = "largeQuickStackHeight",
      d = "largeQuickStackDepthBelow" },
}

-- Full box height and its centre for a station: from (0.5 + depth) below the station up to height - 0.5.
-- With depth 0 this is the game's own placement (box bottom 0.5 below the station).
local function vertical(cfg, station)
    local height, depth = cfg[station.h], cfg[station.d]
    return height + depth, (height - depth) / 2 - 0.5
end

local function patchStation(data, station, cfg)
    local components = field(data, "components")
    local sizeX, sizeY = cfg[station.x], cfg[station.y]
    local height, offsetY = vertical(cfg, station)
    local result = { shape = false, outline = false }

    local shape = findComponent(components, "keen::ecs::TriggerShape")
    if shape and tostring(field(shape, "shape")) == "Box" then
        local before = string.format("%sx%s h%s", size(field(shape, "rangeX")),
            size(field(shape, "rangeZ")), size(field(shape, "rangeY")))
        local ok = setField(shape, "rangeX", sizeX / 2)
            and setField(shape, "rangeZ", sizeY / 2)
            and setField(shape, "rangeY", height / 2)
        local localOffset = field(field(shape, "offset"), "localOffset")
        ok = ok and setField(localOffset, "y", offsetY)
        -- read back so the log shows what the game will really get
        result.shape = ok and near(field(shape, "rangeX"), sizeX / 2) and near(field(shape, "rangeZ"), sizeY / 2)
            and near(field(shape, "rangeY"), height / 2)
        result.before = before
    end

    local vfx = findComponent(components, "keen::ecs::VfxParametersTemplateComponent")
    local params = field(field(vfx, "parameters"), "data")
    if params then
        local bx, bh, bz, bo = floatBits(sizeX), floatBits(height), floatBits(sizeY), floatBits(offsetY)
        if bx and bh and bz and bo then
            local ok = setField(params, 1, bx) and setField(params, 2, bh)
                and setField(params, 3, bz) and setField(params, 9, bo)
            result.outline = ok and field(params, 1) == bx and field(params, 2) == bh and field(params, 3) == bz
            if cfg.logDetails then
                print(string.format("%s   outline params now %s/%s/%s offset %s", TAG,
                    tostring(bitsFloat(field(params, 1))), tostring(bitsFloat(field(params, 3))),
                    tostring(bitsFloat(field(params, 2))), tostring(bitsFloat(field(params, 9)))))
            end
        end
    end
    return result
end

local function main()
    local cfg = loadSettings()
    local side = "client"
    if field(loader, "is_server") then side = "server" end

    if not cfg.enabled then
        print(TAG .. " v" .. VERSION .. " on " .. side .. ": disabled in config.txt, nothing changed")
        return
    end

    local templates = game.assets.get_resources_by_type("keen::ecs::TemplateResource")
    local byName = {}
    for _, station in ipairs(STATIONS) do byName[station.template] = station end

    local parts = {}
    local found = 0
    for _, resource in ipairs(templates) do
        local data = field(resource, "data")
        local station = byName[tostring(field(data, "name"))]
        if station then
            found = found + 1
            local r = patchStation(data, station, cfg)
            parts[#parts + 1] = string.format("%s %sx%s h%s below%s (was %s) area=%s outline=%s",
                station.label, tostring(cfg[station.x]), tostring(cfg[station.y]), tostring(cfg[station.h]),
                tostring(cfg[station.d]), tostring(r.before), r.shape and "ok" or "FAILED", r.outline and "ok" or "FAILED")
        end
    end

    -- Placement preview outline: the square shown while you hold a station is not drawn from the station
    -- template. Its values sit in another parameter block (live memory: offset 0/1.5/0, then 16,4,16,3,
    -- colour,...) - most likely the outline effect's own defaults (keen::VfxResource.defaultParameterData).
    -- Search every place that can hold such a block; match strictly: the outline colour 0xFFE4FF00 present
    -- and the first three values equal to a station's original full sizes (normal 16/4/16, large 24/8/24).
    local COLOUR = 4293197568
    -- Each preview: the station's original full sizes (X, height, Z) and its original height offset.
    -- The values sit at different positions in different blocks (template: 1-3; outline effect defaults:
    -- [0, offsetY, 0, X, height, Z, ...]), so the size triple is searched at every position.
    local previews = {
        { x = floatBits(16), h = floatBits(4), z = floatBits(16), oy = floatBits(1.5), station = STATIONS[1] },
        { x = floatBits(24), h = floatBits(8), z = floatBits(24), oy = floatBits(3.5), station = STATIONS[2] },
    }
    local previewNames = {}
    local function tryBlock(params, label)
        if not params then return end
        local v = {}
        local hasColour = false
        for i = 1, 16 do
            v[i] = field(params, i)
            if v[i] == COLOUR then hasColour = true end
        end
        if not hasColour then return end
        for _, p in ipairs(previews) do
            for i = 1, 14 do
                if v[i] == p.x and v[i + 1] == p.h and v[i + 2] == p.z then
                    local s = p.station
                    local fullHeight, offsetY = vertical(cfg, s)
                    local ok = setField(params, i, floatBits(cfg[s.x]))
                        and setField(params, i + 1, floatBits(fullHeight))
                        and setField(params, i + 2, floatBits(cfg[s.y]))
                    -- effect defaults keep the outline's height offset two values before the sizes
                    if i >= 3 and v[i - 2] == p.oy then
                        ok = setField(params, i - 2, floatBits(offsetY)) and ok
                    end
                    previewNames[#previewNames + 1] = label .. " @" .. i .. (ok and "" or " (FAILED)")
                    return
                end
            end
        end
    end

    for _, resource in ipairs(templates) do
        local data = field(resource, "data")
        local name = tostring(field(data, "name"))
        if not byName[name] then
            for _, kind in ipairs({ "keen::ecs::VfxParametersTemplateComponent", "keen::ecs::VfxParametersOverwriteComponent" }) do
                local c = findComponent(field(data, "components"), kind)
                tryBlock(field(field(c, "parameters"), "data"), "template " .. name)
            end
        end
    end
    local sources = {
        { type = "keen::VfxResource", field = "defaultParameterData" },
        { type = "keen::NotifierResource", field = "defaultVfxInitParameters" },
    }
    for _, src in ipairs(sources) do
        local okList, list = pcall(game.assets.get_resources_by_type, src.type)
        if okList and type(list) == "table" then
            for index, resource in ipairs(list) do
                local block = field(field(resource, "data"), src.field)
                tryBlock(field(block, "data"), src.type .. " " .. tostring(field(resource, "guid")))
                if index % 200 == 0 then collectgarbage() end
            end
        else
            print(TAG .. " could not list " .. src.type)
        end
    end
    parts[#parts + 1] = "preview outlines patched: " .. #previewNames ..
        (#previewNames > 0 and (" (" .. table.concat(previewNames, ", ") .. ")") or "")

    print(TAG .. " v" .. VERSION .. " on " .. side .. ": " .. (#parts > 0 and table.concat(parts, " | ") or "nothing patched"))
    if found < #STATIONS then
        print(TAG .. " WARNING: found " .. found .. " of " .. #STATIONS ..
            " station templates; a game update may have changed the data (update the mod)")
    end
end

local ok, err = pcall(main)
if not ok then
    print(TAG .. " ERROR (the patch stopped early; the stations may be only partly changed): " .. tostring(err))
end
